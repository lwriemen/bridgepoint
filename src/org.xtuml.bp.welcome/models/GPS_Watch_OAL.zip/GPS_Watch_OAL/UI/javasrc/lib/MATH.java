package lib;

public class MATH {
	public static float sqrt( float x ) {
		return (float) java.lang.Math.sqrt( x );
	}
}